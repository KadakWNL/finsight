FinSight
Shrikar Desai | Shreyas P Kulkarni

ONE A4 landscape page per diagram. Print on A4 at 100%. All current attributes retained; no poster-size masters.
