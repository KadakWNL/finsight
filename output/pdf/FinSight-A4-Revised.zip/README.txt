FinSight
Shrikar Desai | Shreyas P Kulkarni

One A4 landscape page per diagram. ER relationships use separate short drawings; schema FKs use short local arrows with exact named targets. No page-wide or shared routes remain.
