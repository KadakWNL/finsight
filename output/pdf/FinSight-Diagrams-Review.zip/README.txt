FinSight
Shrikar Desai | Shreyas P Kulkarni

ER master: A0 landscape. Schema master: A1 landscape. Both PDFs are vector and support zoom. Print at native size for readable attributes; do not shrink the full poster to A4.

Verified against main 843f0af9597439cafefe35c62dea8b9be29540bb, migrations 010 through 060, and the current Mongo validator. Contains all 17 application tables, migration bookkeeping, the derived risk view and Mongo telemetry.

Older repository ER design figures contain deferred entities and are not the current print masters.
